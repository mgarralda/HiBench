"""Independent full-row checks after the timed campaign; never during measurements."""
import json
from pathlib import Path
import subprocess
import re
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'pyproject.toml').exists() and (p/'hibench').is_dir())
OUT=ROOT/'report/ssrn-v250-final-20261016'
assert 'completed_utc' in json.loads((OUT/'campaign.json').read_text())
manifests=[json.loads(p.read_text()) for p in (OUT/'controller/datasets').glob('*.json')]
payload=json.dumps([dict(workload=m['workload']['id'],path=m['input_path'],scale=m['scale']) for m in manifests])
code='''import json
from pyspark.sql import SparkSession,functions as F
from pyspark.ml.functions import vector_to_array
spark=SparkSession.builder.appName('SSRN independent dataset verification').getOrCreate()
results=[]
for item in ITEMS:
 d=spark.read.parquet(item['path'])
 dims=F.size(vector_to_array('features'))
 row=d.agg(F.count('*').alias('rows'),F.countDistinct('id').alias('distinct_ids'),F.min('id').alias('min_id'),F.max('id').alias('max_id'),F.min(dims).alias('min_features'),F.max(dims).alias('max_features')).first().asDict()
 results.append(dict(**item,**row,schema=d.schema.jsonValue()))
print('SSRN_INPUT_CHECK='+json.dumps(results))
spark.stop()
'''.replace('ITEMS',payload)
path=OUT/'verify_inputs_spark.py';path.write_text(code)
if not (OUT/'independent-input-checks.json').exists():
 subprocess.run(['docker','cp',str(path),'spark-cluster-master:/tmp/ssrn-final-verify-inputs.py'],check=True)
 r=subprocess.run(['docker','exec','spark-cluster-master','/usr/local/spark/bin/spark-submit',
 '--master','yarn','--deploy-mode','client','--num-executors','2','--executor-cores','2',
 '--executor-memory','2g','--driver-memory','2g','--conf','spark.sql.parquet.columnarReaderBatchSize=256',
 '--conf','spark.pyspark.python=/opt/pyspark/bin/python','/tmp/ssrn-final-verify-inputs.py'],
  stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
 (OUT/'independent-input-check.log').write_bytes(r.stdout)
 lines=r.stdout.decode(errors='replace').splitlines()
 checks=json.loads(next(x.split('=',1)[1] for x in lines if x.startswith('SSRN_INPUT_CHECK=')))
else:
 checks=json.loads((OUT/'independent-input-checks.json').read_text())
for c in checks:
 expected=500000 if c['workload']=='ml.svd' else 4000000
 assert c['rows']==c['distinct_ids']==expected
 assert c['min_features']==c['max_features']==1000
 assert c['max_id']-c['min_id']+1==expected
(OUT/'independent-input-checks.json').write_text(json.dumps(checks,indent=2))
files=[]
for m in manifests if not (OUT/'dataset-file-checksums.json').exists() else []:
 listing=subprocess.check_output(['docker','exec','spark-cluster-master','hdfs','dfs','-ls','-R',m['input_path']],stderr=subprocess.STDOUT).decode()
 for line in listing.splitlines():
  fields=line.split()
  if fields and fields[0].startswith('-'):
   p=fields[-1]
   checksum=subprocess.check_output(['docker','exec','spark-cluster-master','hdfs','dfs','-checksum',p]).decode().strip()
   files.append(dict(workload=m['workload']['id'],path=p,size_bytes=int(fields[4]),hdfs_checksum=checksum))
if files:(OUT/'dataset-file-checksums.json').write_text(json.dumps(files,indent=2))
print('Full input checks passed',flush=True)

# Independent History REST summaries corroborate the raw TaskEnd counter sums.
import urllib.request
crosschecks=[]
campaign=json.loads((OUT/'campaign.json').read_text())
for r in campaign['runs']:
 directory=OUT/'runs'/r['key']
 app=(r['metrics'][0]['application_id'] if r['metrics'] else
      re.search(r'HIBENCH_APPLICATION_ID=(application_\d+_\d+)',(directory/'output.log').read_text()).group(1))
 # Preserve the original bytes from HDFS, including original line endings.
 raw_bytes=subprocess.check_output(['docker','exec','spark-cluster-master','hdfs','dfs','-cat','/shared/spark-logs/'+app])
 (directory/(app+'.jsonl')).write_bytes(raw_bytes)
 if r['role']!='measurement':continue
 stages=json.load(urllib.request.urlopen('http://127.0.0.1:18080/api/v1/applications/'+app+'/stages',timeout=90))
 (directory/'history-stages.json').write_text(json.dumps(stages,indent=2))
 events=[json.loads(line) for line in (directory/(app+'.jsonl')).open()]
 tasks=[e for e in events if e['Event']=='SparkListenerTaskEnd']
 completed=[s for s in stages if s['status']=='COMPLETE']
 checks=dict(application_id=app,case=r['case'],implementation=r['implementation'],pair=r['pair'],
   task_count=len(tasks),history_task_count=sum(s['numCompleteTasks'] for s in completed),
   raw_executor_runtime_ms=sum(t['Task Metrics']['Executor Run Time'] for t in tasks),
   history_executor_runtime_ms=sum(s['executorRunTime'] for s in completed),
   raw_jvm_cpu_ns=sum(t['Task Metrics']['Executor CPU Time'] for t in tasks),
   history_jvm_cpu_ns=sum(s['executorCpuTime'] for s in completed))
 assert checks['task_count']==checks['history_task_count']
 assert checks['raw_executor_runtime_ms']==checks['history_executor_runtime_ms']
 assert checks['raw_jvm_cpu_ns']==checks['history_jvm_cpu_ns']
 crosschecks.append(checks)
(OUT/'history-crosschecks.json').write_text(json.dumps(crosschecks,indent=2))
print('History counter cross-checks passed',flush=True)

native_code='''import glob,hashlib,json,os,platform
paths=glob.glob('/opt/pyspark/lib/python3.10/site-packages/numpy.libs/*')
paths+=glob.glob('/usr/local/spark/jars/breeze*.jar')+glob.glob('/usr/local/spark/jars/*netlib*.jar')
paths+=['/lib/x86_64-linux-gnu/libopenblas.so.0','/lib/x86_64-linux-gnu/liblapack.so.3','/lib/x86_64-linux-gnu/libblas.so.3']
out=[]
for p in paths:
 if os.path.isfile(p):
  with open(p,'rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest() if hasattr(hashlib,'file_digest') else hashlib.sha256(f.read()).hexdigest()
  out.append(dict(path=p,resolved=os.path.realpath(p),sha256=digest))
print(json.dumps(dict(machine=platform.machine(),platform=platform.platform(),artifacts=out),indent=2))
'''
native=subprocess.check_output(['docker','exec','spark-cluster-master','/opt/pyspark/bin/python','-c',native_code])
(OUT/'numerical-library-hashes.json').write_bytes(native)
print('Native artifact identities recorded',flush=True)
