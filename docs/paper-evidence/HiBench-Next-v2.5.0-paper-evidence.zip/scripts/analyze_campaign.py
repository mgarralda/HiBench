"""Parse original event logs and regenerate paper tables/figures, offline."""
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics as stats
import shutil
import zipfile
import numpy as np
ROOT=next(p for p in Path(__file__).resolve().parents if (p/'pyproject.toml').exists() and (p/'hibench').is_dir())
SRC=ROOT/'report/ssrn-v250-final-20261016'
OUT=SRC/'derived'
OUT.mkdir(exist_ok=True)
os.environ['MPLCONFIGDIR']=str(SRC/'.matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

FIELDS=[('ExecutorRunTime','Executor Run Time','ms'),('ExecutorCPUTime','Executor CPU Time','ns'),
('ExecutorDeserializeTime','Executor Deserialize Time','ms'),('ExecutorDeserializeCPUTime','Executor Deserialize CPU Time','ns'),
('ResultSize','Result Size','bytes'),('JVMGCTime','JVM GC Time','ms'),('ResultSerializationTime','Result Serialization Time','ms'),
('MemoryBytesSpilled','Memory Bytes Spilled','bytes'),('DiskBytesSpilled','Disk Bytes Spilled','bytes'),
('PeakExecutionMemory','Peak Execution Memory','bytes'),('Input:BytesRead','Input Metrics.Bytes Read','bytes'),
('Input:RecordsRead','Input Metrics.Records Read','records'),('Output:BytesWritten','Output Metrics.Bytes Written','bytes'),
('Output:RecordsWritten','Output Metrics.Records Written','records'),('ShuffleRead:RecordsRead','Shuffle Read Metrics.Total Records Read','records'),
('ShuffleRead:RemoteBlocksFetched','Shuffle Read Metrics.Remote Blocks Fetched','blocks'),
('ShuffleRead:LocalBlocksFetched','Shuffle Read Metrics.Local Blocks Fetched','blocks'),
('ShuffleRead:RemoteBytesRead','Shuffle Read Metrics.Remote Bytes Read','bytes'),
('ShuffleRead:LocalBytesRead','Shuffle Read Metrics.Local Bytes Read','bytes'),
('ShuffleRead:RemoteBytesReadDisk','Shuffle Read Metrics.Remote Bytes Read To Disk','bytes'),
('ShuffleRead:FetchWaitTime','Shuffle Read Metrics.Fetch Wait Time','ms'),
('ShuffleWrite:BytesWritten','Shuffle Write Metrics.Shuffle Bytes Written','bytes'),
('ShuffleWrite:RecordsWritten','Shuffle Write Metrics.Shuffle Records Written','records'),
('ShuffleWrite:WriteTime','Shuffle Write Metrics.Shuffle Write Time','ns'),('TasksPerStage',None,'tasks')]

def writecsv(name,rows):
    if not rows:return
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def get(d,path):
    for key in path.split('.'):
        if not isinstance(d,dict) or key not in d:return None
        d=d[key]
    return d

def union(intervals):
    end=None;total=0
    for a,b in sorted(intervals):
        if end is None or a>end:total+=b-a
        elif b>end:total+=b-end
        end=max(end or b,b)
    return total/1000

def transform(v):
    v=np.array(v,dtype=float)
    n=len(v);u=(v-v.min())/np.ptp(v) if np.ptp(v) else np.zeros(n)
    z=(v-v.mean())/v.std(ddof=0) if v.std(ddof=0) else np.zeros(n)
    c=np.cumsum(z);x=np.linspace(0,1,n)
    fit=np.polynomial.polynomial.polyval(x,np.polynomial.polynomial.polyfit(x,c,2)) if n>=3 else np.zeros(n)
    return u,c,fit

manifest=json.loads((SRC/'campaign.json').read_text())
observations=[];tasks_rows=[];stage_rows=[];metric_rows=[];phase_rows=[];plans=[];correctness=[];series={};environments={}
for receipt in manifest['runs']:
    if receipt['role']!='measurement' or not receipt.get('archived'):continue
    directory=SRC/'runs'/receipt['key']
    tasklist=[];stageinfo={};jobs={};jobends={};apps={};sql={};events_count=0;env={}
    for p in directory.glob('application_*.jsonl'):
        for line in p.open(encoding='utf-8'):
            e=json.loads(line);events_count+=1;name=e.get('Event','')
            if name=='SparkListenerApplicationStart':apps['start']=e['Timestamp'];apps['id']=e['App ID']
            elif name=='SparkListenerApplicationEnd':apps['end']=e['Timestamp']
            elif name=='SparkListenerEnvironmentUpdate':env=e
            elif name=='SparkListenerTaskEnd':tasklist.append(e)
            elif name=='SparkListenerStageCompleted':
                s=e['Stage Info'];stageinfo[(s['Stage ID'],s['Stage Attempt ID'])]=s
            elif name=='SparkListenerJobStart':jobs[e['Job ID']]=e
            elif name=='SparkListenerJobEnd':jobends[e['Job ID']]=e
            elif name.endswith('SparkListenerSQLExecutionStart'):
                sql.setdefault(str(e['executionId']),{}).update(start=e.get('time'),plan=e.get('physicalPlanDescription',''),description=e.get('description',''))
            elif name.endswith('SparkListenerSQLExecutionEnd'):sql.setdefault(str(e['executionId']),{})['end']=e.get('time')
            elif name.endswith('SparkListenerSQLAdaptiveExecutionUpdate'):
                sql.setdefault(str(e['executionId']),{})['adaptive_plan']=e.get('physicalPlanDescription','')
    assert 'start' in apps and 'end' in apps
    tasklist.sort(key=lambda e:e['Task Info']['Task ID'])
    metric=receipt['metrics'][0]
    base=dict(case=receipt['case'],workload=receipt['workload'],scale=receipt['scale'],pair=receipt['pair'],
              implementation=receipt['implementation'],run_id=receipt['run_id'],application_id=apps['id'])
    failed=[e for e in tasklist if e['Task End Reason'].get('Reason')!='Success']
    assert not failed,(base,failed)
    assert len(tasklist)==sum(s['Number of Tasks'] for s in stageinfo.values())
    props=dict(env['Spark Properties'])
    assert props['spark.master']=='yarn' and props['spark.submit.deployMode']=='client'
    assert props['spark.executor.instances']=='2'
    assert props['spark.executor.cores']==('2' if receipt['scale']=='large' else '1')
    assert props['spark.executor.memory']==props['spark.driver.memory']=='2g'
    intervals=[(j['Submission Time'],jobends[k]['Completion Time']) for k,j in jobs.items() if k in jobends]
    assert len(intervals)==len(jobs)
    requested={s['Stage ID'] for j in jobs.values() for s in j['Stage Infos']}
    obs={**base,'submission_s':metric['duration_s'],'application_s':(apps['end']-apps['start'])/1000,
         'job_interval_union_s':union(intervals),'jobs':len(jobs),'executed_stage_attempts':len(stageinfo),
         'skipped_stage_ids':len(requested-{k[0] for k in stageinfo}),
         'successful_tasks':len(tasklist),'failed_tasks':len(failed),'events':events_count}
    for name,path,unit in FIELDS:
        vals=[]
        for pos,t in enumerate(tasklist):
            s=stageinfo[(t['Stage ID'],t['Stage Attempt ID'])]
            value=get(t.get('Task Metrics',{}),path) if path else s['Number of Tasks']
            if value is None: raise ValueError(f'Missing counter {name} in {base}')
            vals.append(value)
            info=t['Task Info']
            tasks_rows.append({**base,'task_position':pos,'task_id':info['Task ID'],'stage_id':t['Stage ID'],
                'stage_attempt':t['Stage Attempt ID'],'partition_index':info['Index'],
                'task_attempt':info['Attempt'],'executor_id':info['Executor ID'],'host':info['Host'],
                'launch_ms':info['Launch Time'],'finish_ms':info['Finish Time'],
                'metric':name,'unit':unit,'raw_value':value})
        metric_rows.append({**base,'metric':name,'unit':unit,'sum':sum(vals),'median':stats.median(vals),
                            'minimum':min(vals),'maximum':max(vals),'count':len(vals)})
        if path:
            factor=1e9 if unit=='ns' else 1000 if unit=='ms' else 1
            obs[name+'_sum']=sum(vals)/factor
    obs['TaskDuration_sum']=sum(t['Task Info']['Finish Time']-t['Task Info']['Launch Time'] for t in tasklist)/1000
    durations=[t['Task Info']['Finish Time']-t['Task Info']['Launch Time'] for t in tasklist]
    metric_rows.append({**base,'metric':'TaskDuration','unit':'ms','sum':sum(durations),'median':stats.median(durations),
                        'minimum':min(durations),'maximum':max(durations),'count':len(durations)})
    observations.append(obs)
    series[(receipt['case'],receipt['pair'],receipt['implementation'])]=tasklist
    for key,s in stageinfo.items():
        st=[t for t in tasklist if (t['Stage ID'],t['Stage Attempt ID'])==key]
        stage_rows.append({**base,'stage_id':key[0],'stage_attempt':key[1],'stage_name':s['Stage Name'],
            'details':s.get('Details',''),'tasks':len(st),'wall_s':(s['Completion Time']-s['Submission Time'])/1000,
            'executor_runtime_sum_s':sum(t['Task Metrics']['Executor Run Time'] for t in st)/1000,
            'jvm_cpu_sum_s':sum(t['Task Metrics']['Executor CPU Time'] for t in st)/1e9,
            'input_bytes':sum(get(t['Task Metrics'],'Input Metrics.Bytes Read') or 0 for t in st),
            'shuffle_write_bytes':sum(get(t['Task Metrics'],'Shuffle Write Metrics.Shuffle Bytes Written') or 0 for t in st)})
    for id,q in sql.items():plans.append({**base,'execution_id':id,**q})
    plan_text='\n\n'.join('SQL execution '+id+'\n'+q.get('plan','')+'\nADAPTIVE PLAN\n'+q.get('adaptive_plan','') for id,q in sql.items())
    (OUT/(receipt['key']+'-plans.txt')).write_text(plan_text,encoding='utf-8')
    environments[receipt['key']]=env
    workload_measurement=metric.get('workload_measurement',{})
    if workload_measurement:phase_rows.append({**base,'measurement':workload_measurement})
    console='\n'.join(p.read_text(encoding='utf-8',errors='replace') for p in directory.rglob('output.log'))
    if receipt['case']=='svd-large':
        matches=re.findall(r'^SVD singularValues=(\[.*\])$',console,re.M)
        assert matches,'Missing SVD values'
        values=json.loads(matches[0]);assert len(values)==100
        correctness.append({**base,'observable':'singular_values','values':values})
    elif receipt['case']=='pca-large':
        matches=re.findall(r'PCA dimensions=1000 k=10 explainedVariance=(\[[^\n]+?\])',console)
        assert matches,'Missing PCA variance'
        values=json.loads(matches[0]);assert len(values)==10
        correctness.append({**base,'observable':'explained_variance','values':values})

writecsv('observations.csv',observations)
writecsv('task-metrics-raw.csv',tasks_rows)
writecsv('stage-metrics.csv',stage_rows)
writecsv('task-metric-summaries.csv',metric_rows)
(OUT/'plans.json').write_text(json.dumps(plans,indent=2))
(OUT/'spark-environments.json').write_text(json.dumps(environments,indent=2))
(OUT/'phase-measurements.json').write_text(json.dumps(phase_rows,indent=2))
(OUT/'numerical-observables.json').write_text(json.dumps(correctness,indent=2))
checks=[]
for case in ('svd-large','pca-large'):
    for pair in range(1,4):
        v=[next((r['values'] for r in correctness if r['case']==case and r['pair']==pair and r['implementation']==lang),None) for lang in ('scala','pyspark')]
        if None in v:continue
        assert all(math.isfinite(x) for a in v for x in a)
        assert np.allclose(*v,rtol=1e-6,atol=1e-8)
        checks.append(dict(case=case,pair=pair,count=len(v[0]),rtol=1e-6,atol=1e-8,
            max_absolute_difference=max(abs(a-b) for a,b in zip(*v)),
            max_relative_difference=max(abs(a-b)/max(abs(a),abs(b),1e-30) for a,b in zip(*v)),passed=True))
(OUT/'numerical-checks.json').write_text(json.dumps(checks,indent=2))

summaries=[]
for case in dict.fromkeys(o['case'] for o in observations):
    for lang in ('scala','pyspark'):
        subset=[o for o in observations if o['case']==case and o['implementation']==lang]
        if not subset:continue
        for key in ('submission_s','application_s','job_interval_union_s','jobs','executed_stage_attempts','successful_tasks',
                    'ExecutorRunTime_sum','ExecutorCPUTime_sum','ExecutorDeserializeTime_sum','ShuffleWrite:BytesWritten_sum'):
            v=[o[key] for o in subset]
            summaries.append(dict(case=case,implementation=lang,metric=key,n=len(v),median=stats.median(v),minimum=min(v),maximum=max(v),sample_stdev=stats.stdev(v) if len(v)>1 else None))
writecsv('replicate-summaries.csv',summaries)

# Stage role is evidence-based: preserve source names/details and physical plans,
# rather than assuming that the same stage ID denotes the same operator.
for base in observations:
    key=(base['case'],base['pair'],base['implementation'])
    if base['case']=='repartition-small':
        assert base['ShuffleWrite:RecordsWritten_sum']>=44800000
    if base['case']=='sleep-small':
        assert base['successful_tasks']>=14

(OUT/'analysis-environment.json').write_text(json.dumps(dict(numpy=np.__version__,matplotlib=matplotlib.__version__),indent=2))

# Unified figure style; no overall titles or in-image captions.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.titlesize':13,
    'axes.labelsize':12,'xtick.labelsize':11,'ytick.labelsize':11,'svg.fonttype':'none'})
colors={'scala':'#1764a0','pyspark':'#d66c16'}
figmetrics=[('Executor Run Time',1000,'Executor runtime\n(s)'),('Executor CPU Time',1e9,'JVM-thread CPU\n(s)'),
            ('Executor Deserialize Time',1000,'Deserialization\n(s)'),('Shuffle Write Metrics.Shuffle Bytes Written',1048576,'Shuffle write\n(MiB)')]
transform_rows=[]
for pair in range(1,4):
    if not all((case,pair,lang) in series for case in ('svd-large','pca-large') for lang in colors):continue
    fig,axes=plt.subplots(2,4,figsize=(10,6.6))
    fig.subplots_adjust(left=.10,right=.985,bottom=.10,top=.89,wspace=.48,hspace=.34)
    for row,case in enumerate(('svd-large','pca-large')):
        for col,(path,divisor,title) in enumerate(figmetrics):
            ax=axes[row,col]
            for lang in colors:
                ts=series[case,pair,lang];v=[get(t['Task Metrics'],path)/divisor for t in ts]
                ax.plot(range(len(v)),v,color=colors[lang],label=lang,linewidth=1,
                    marker='o' if lang=='scala' else 's',markersize=3,alpha=.75,
                    markevery=max(1,len(v)//35),markerfacecolor=colors[lang] if lang=='scala' else 'white')
            if row==0:ax.set_title(title)
            if col==0:ax.set_ylabel('SVD Large' if row==0 else 'PCA Large')
            ax.set_xlabel('Task position')
            ax.set_ylim(bottom=0);ax.grid(alpha=.2);ax.xaxis.set_major_locator(MaxNLocator(integer=True,nbins=5))
            ref=series[case,pair,'scala']
            for i in range(1,len(ref)):
                if ref[i]['Stage ID']!=ref[i-1]['Stage ID']:ax.axvline(i-.5,color='.6',linestyle=':',linewidth=.6,zorder=0)
    axes[0,0].legend(fontsize=11)
    for ext in ('png','svg'):fig.savefig(OUT/f'figure4-raw-pair{pair}.{ext}',dpi=300)
    plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(10,6.2))
    fig.subplots_adjust(left=.10,right=.985,bottom=.10,top=.89,wspace=.36,hspace=.34)
    for row,case in enumerate(('svd-large','pca-large')):
        for lang in colors:
            ts=series[case,pair,lang];v=np.array([t['Task Metrics']['Executor Run Time']/1000 for t in ts])
            u,c,fit=transform(v)
            for col,values in enumerate((v,u,c)):
                axes[row,col].plot(range(len(v)),values,color=colors[lang],label=lang,linewidth=1,
                    marker='o' if lang=='scala' else 's',markersize=2.5,markevery=max(1,len(v)//35),
                    markerfacecolor=colors[lang] if lang=='scala' else 'white')
            axes[row,2].plot(range(len(v)),fit,'--',color=colors[lang],linewidth=1.5)
            transform_rows.extend(dict(case=case,pair=pair,implementation=lang,position=i,task_id=t['Task Info']['Task ID'],
                stage_id=t['Stage ID'],raw_seconds=float(v[i]),minmax=float(u[i]),cusum=float(c[i]),quadratic_fit=float(fit[i])) for i,t in enumerate(ts))
        for col,title in enumerate(('Raw executor runtime\n(s)','Independent\nmin-max','CUSUM +\nquadratic fit')):
            ax=axes[row,col]
            if row==0:ax.set_title(title)
            ax.set_xlabel('Task position');ax.grid(alpha=.2);ax.xaxis.set_major_locator(MaxNLocator(integer=True,nbins=5))
        axes[row,0].set_ylabel('SVD Large' if row==0 else 'PCA Large')
    axes[0,0].legend(fontsize=11)
    for ext in ('png','svg'):fig.savefig(OUT/f'figure5-transforms-pair{pair}.{ext}',dpi=300)
    plt.close(fig)
writecsv('figure5-transformed-values.csv',transform_rows)

# SVD path diagram: unchanged mechanism, consistent typography and no caption.
from matplotlib.patches import FancyBboxPatch
fig,ax=plt.subplots(figsize=(10,3.1),layout='constrained')
ax.set_xlim(0,13);ax.set_ylim(-.2,3);ax.axis('off')
labels=[['Parquet scan','Typed packed-Gram\npartials','Exchange, merge\nand collect','Breeze / netlib\ndsyev'],
        ['Parquet scan;\nvector-to-array','Python / Arrow\nNumPy partials','Exchange; Arrow\nmerge and collect','NumPy\ndsyevd']]
for row,lang in enumerate(('Scala','PySpark')):
 y=2.1-row*1.45;ax.text(.05,y,lang,ha='left',va='center',fontsize=13)
 for col in range(4):
  x=1.5+col*2.8;fill='#f9e5d3' if col==3 else '#e8e2f5' if col==1 or (row==1 and col==2) else '#deebfa'
  ax.add_patch(FancyBboxPatch((x,y-.4),2.4,.8,boxstyle='round,pad=0.06',facecolor=fill,edgecolor='#26334e',linewidth=.8))
  ax.text(x+1.2,y,labels[row][col],ha='center',va='center',fontsize=13)
  if col<3:ax.annotate('',xy=(x+2.75,y),xytext=(x+2.46,y),arrowprops=dict(arrowstyle='->',color='#26334e',lw=.8))
ax.axvline(9.65,ymin=.04,ymax=.94,color='#568b58',linestyle='--',linewidth=1)
ax.text(9.65,2.72,'Driver boundary',ha='center',fontsize=12)
for ext in ('png','svg'):fig.savefig(OUT/f'figure3-svd-paths.{ext}',dpi=300)
plt.close(fig)
print(json.dumps(dict(measured_applications=len(observations),numerical_pairs=len(checks),task_metric_rows=len(tasks_rows)),indent=2))
