"""Final v2.5.0 paper campaign. Run from repository root; resumable receipts."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = next(p for p in Path(__file__).resolve().parents if (p/'pyproject.toml').exists() and (p/'hibench').is_dir())
OUT = ROOT / 'report' / 'ssrn-v250-final-20261016'
OUT.mkdir(exist_ok=True)
os.environ['HIBENCH_STATE_DIR'] = str(OUT / 'controller')
from hibench import config, store
from hibench.services import experiments
from hibench.services.runtime import install
from hibench.adapters import create_adapter

def save(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')

def command(argv):
    return subprocess.check_output(argv, stderr=subprocess.STDOUT).decode('utf-8', errors='replace')

manifest_path = OUT / 'campaign.json'
target = json.loads((ROOT / 'report/svd-duration-calibration-500k-experiment.json').read_text())['target']
target.update(dataset_base='hdfs://spark-cluster-master:9000/HiBench-SSRN-v250-20261016/datasets',
              output_base='hdfs://spark-cluster-master:9000/HiBench-SSRN-v250-20261016/outputs',
              report_base='/home/sparker/HiBench/report/ssrn-v250-20261016')
cases = [('svd-large', 'ml.svd', 'large', {}, True),
         ('pca-large', 'ml.pca', 'large', {}, True),
         ('repartition-small', 'micro.repartition', 'small', {'fromhdfs': False}, False),
         ('sleep-small', 'micro.sleep', 'small', {}, False)]
if manifest_path.exists():
    manifest = json.loads(manifest_path.read_text())
else:
    manifest = dict(protocol='ssrn-v250-final-v1', release_tag='v2.5.0',
                    release_commit=command(['git','rev-parse','v2.5.0^{commit}']).strip(),
                    controller_commit=command(['git','rev-parse','HEAD']).strip(),
                    created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                    pairs=3, warmups_per_implementation=1,
                    order='Measured pairs: Scala/PySpark, PySpark/Scala, Scala/PySpark',
                    figure_pair=1,
                    figure_selection='First measured pair fixed before execution; all pairs retained',
                    dataset_policy='Generate once per materialized workload; reuse immutable controller manifest',
                    scope='SVD/PCA Large, in-memory Repartition Small, Sleep Small; current release presets',
                    acceptance=dict(rtol=1e-6, atol=1e-8, finite=True), runs=[])
    save(manifest_path, manifest)

if not (OUT / 'installed.txt').exists():
    (OUT / 'install.txt').write_text(install(target), encoding='utf-8')
    backend = create_adapter(target)
    (OUT / 'doctor.txt').write_text(backend.doctor(), encoding='utf-8')
    (OUT / 'docker-inspect.json').write_text(command(['docker','inspect',target['container'],*target['workers']]), encoding='utf-8')
    jar = 'sparkbench/assembly/target/sparkbench-assembly-2.5.0-dist.jar'
    localhash = hashlib.sha256((ROOT/jar).read_bytes()).hexdigest()
    remotehash = command(['docker','exec',target['container'],'sha256sum',target['workspace']+'/'+jar]).split()[0]
    assert localhash == remotehash
    closure = json.loads((ROOT/'report/release-v2.5.0-closure/validation.json').read_text())
    assert localhash == closure['artifact_sha256'][jar]
    save(OUT/'artifact-provenance.json', dict(jar=jar, sha256=localhash,
         release_validation='report/release-v2.5.0-closure/validation.json',
         source_diff_from_tag=command(['git','diff','v2.5.0','--','sparkbench','pysparkbench','conf','bin'])))
    envscript = '''import json,platform,os,numpy,pandas,pyarrow
from contextlib import redirect_stdout
import io
s=io.StringIO()
with redirect_stdout(s): numpy.show_config()
print(json.dumps(dict(python=platform.python_version(),numpy=numpy.__version__,pandas=pandas.__version__,pyarrow=pyarrow.__version__,numpy_config=s.getvalue())))'''
    (OUT/'numerical-environment.json').write_text(command(['docker','exec',target['container'],'/opt/pyspark/bin/python','-c',envscript]), encoding='utf-8')
    (OUT/'native-libraries.txt').write_text(command(['docker','exec',target['container'],'bash','-lc','ldconfig -p | grep -E "blas|lapack" || true']), encoding='utf-8')
    (OUT/'installed.txt').write_text('Installed and verified release artifacts\n')

for label, workload, scale, parameters, prepare in cases:
    spec = config.resolve(dict(name='SSRN final '+label, target=target, scale=scale,
        workloads=[dict(id=workload, parameters=parameters)], implementation='scala',
        repetitions=1, mode='run', timeout_s=2400,
        monitoring=dict(enabled=True, interval_s=5), execution_group='ssrn-final-'+label))
    save(OUT/(label+'-resolved.json'), spec)
    sequence = [('prepare', 0, 'scala')] if prepare else []
    sequence += [('warmup', 0, lang) for lang in ('scala','pyspark')]
    for pair in range(1,4):
        sequence += [('measurement', pair, lang) for lang in
                     (('scala','pyspark') if pair%2 else ('pyspark','scala'))]
    for role, pair, lang in sequence:
        key = f'{label}-{role}-{pair}-{lang}'
        receipt = next((r for r in manifest['runs'] if r['key']==key), None)
        if receipt and receipt.get('state')=='succeeded' and receipt.get('archived'):
            continue
        run_spec = copy.deepcopy(spec)
        run_spec.update(name=key, implementation=lang, mode='prepare' if role=='prepare' else 'run')
        if receipt is None:
            receipt = dict(key=key,case=label,workload=workload,scale=scale,role=role,pair=pair,implementation=lang,
                           run_id=experiments.submit(run_spec)['run_id'])
            manifest['runs'].append(receipt)
            save(manifest_path,manifest)
        print(json.dumps(receipt),flush=True)
        while store.get(receipt['run_id'])['state'] not in ('succeeded','failed','cancelled'):
            time.sleep(2)
        result = experiments.results(receipt['run_id'])
        directory = OUT/'runs'/key
        directory.mkdir(parents=True,exist_ok=True)
        save(directory/'results.json',result)
        receipt['state']=result['run']['state']
        receipt['metrics']=result['metrics']
        save(manifest_path,manifest)
        if receipt['state']!='succeeded':
            raise RuntimeError(f"Stopped at {key}: {result['run']['detail']}")
        # Copy exact controller provenance, console and per-phase resource evidence.
        for p in store.directory(receipt['run_id']).iterdir():
            dest=directory/p.name
            if p.is_dir(): shutil.copytree(p,dest,dirs_exist_ok=True)
            else: shutil.copy2(p,dest)
        for metric in result['metrics']:
            app=metric.get('application_id')
            if not app: raise RuntimeError('Missing application ID')
            events = subprocess.check_output(['docker','exec',target['container'],'hdfs','dfs','-cat','/shared/spark-logs/'+app])
            (directory/(app+'.jsonl')).write_bytes(events)
        if role=='prepare' and not result['metrics']:
            import re
            app=re.search(r'HIBENCH_APPLICATION_ID=(application_\d+_\d+)',(directory/'output.log').read_text()).group(1)
            events=subprocess.check_output(['docker','exec',target['container'],'hdfs','dfs','-cat','/shared/spark-logs/'+app])
            (directory/(app+'.jsonl')).write_bytes(events)
        receipt['archived']=True
        save(manifest_path,manifest)
        print('ARCHIVED '+key,flush=True)
manifest['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
save(manifest_path,manifest)
print('CAMPAIGN COMPLETE',flush=True)
