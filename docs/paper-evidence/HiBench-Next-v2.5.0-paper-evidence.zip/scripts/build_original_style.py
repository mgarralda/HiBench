"""Original visual style with explicitly labelled PCA detail and complete supplements."""
import csv
import hashlib
import json
import os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'output/ssrn-v250-final-20261016'
OUT=ROOT/'output/paper-figures-final'
OUT.mkdir(exist_ok=True)
os.environ['MPLCONFIGDIR']=str(ROOT/'report/paper-review-main27/mpl-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
import numpy as np
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,
 'axes.titlesize':12,'axes.labelsize':11,'xtick.labelsize':10,
 'ytick.labelsize':10,'svg.fonttype':'none','path.simplify':False})
colors={'scala':'#1764a0','pyspark':'#d66c16'}
raw={}
with (SRC/'task-metrics-raw.csv').open() as f:
 for r in csv.DictReader(f):
  if r['pair']=='1' and r['case'] in ('svd-large','pca-large'):
   raw.setdefault((r['case'],r['implementation'],r['metric']),[]).append(r)
with (SRC/'figure5-transformed-values.csv').open() as f:
 trans=[r for r in csv.DictReader(f) if r['pair']=='1']
windows={}
for lang in colors:
 rows=raw['pca-large',lang,'ExecutorRunTime']
 assert len(rows)==1047
 # Fixed rule: first 40 consecutive task positions in final 500-task stage.
 groups={}
 for r in rows:groups.setdefault(int(r['stage_id']),[]).append(r)
 stage=max(k for k,v in groups.items() if len(v)==500)
 positions=[int(r['task_position']) for r in groups[stage][:40]]
 assert positions==list(range(positions[0],positions[0]+40))
 windows[lang]=positions
assert windows['scala']==windows['pyspark']==list(range(526,566))
metrics=[('ExecutorRunTime',1000,'Executor run time (s)'),
 ('ExecutorCPUTime',1e9,'Executor JVM CPU time (s)'),
 ('ExecutorDeserializeTime',1000,'Executor deserialize time (s)'),
 ('ShuffleWrite:BytesWritten',1048576,'Shuffle write (MiB)')]
records=[]
def setup(ax,title):
 ax.set_title(title,pad=9)
 ax.set_xlabel('Task position (ascending Task ID)')
 ax.grid(alpha=.2)
 ax.xaxis.set_major_locator(MaxNLocator(integer=True,nbins=6))
 ax.tick_params(length=3,width=.6)
 for sp in ax.spines.values():sp.set_linewidth(.7)
def save(fig,name):
 # Series must remain line artists: no filled areas or scatter markers.
 for ax in fig.axes:
  assert not ax.collections
  for line in ax.lines:assert line.get_marker() in ('None',None,'')
 for ext in ('png','svg'):fig.savefig(OUT/f'{name}.{ext}',dpi=350)
 plt.close(fig)
for full in (False,True):
 suffix='-complete' if full else ''
 fig,axes=plt.subplots(2,4,figsize=(15,7))
 fig.subplots_adjust(left=.055,right=.99,bottom=.10,top=.90,wspace=.30,hspace=.55)
 for row,case in enumerate(('svd-large','pca-large')):
  detail=case=='pca-large' and not full
  name='SVD Large' if row==0 else 'PCA Large'
  heading=name+(' — detail 526–565' if detail else ' — all tasks')
  for col,(metric,divisor,title) in enumerate(metrics):
   ax=axes[row,col]
   for lang,color in colors.items():
    rows=raw[case,lang,metric]
    rows=[r for r in rows if not detail or int(r['task_position']) in windows[lang]]
    x=[int(r['task_position']) for r in rows]
    y=[float(r['raw_value'])/divisor for r in rows]
    ax.plot(x,y,color=color,lw=1.25,label='Scala' if lang=='scala' else 'PySpark')
    if not full:
     records.extend(dict(figure=4,case=case,implementation=lang,metric=metric,
      position=i,value=v,view='detail' if detail else 'complete') for i,v in zip(x,y))
   setup(ax,heading+'\n'+title)
   ax.set_ylim(bottom=0)
   if col==0:ax.legend(loc='best',fontsize=10)
 save(fig,'figure4-raw'+suffix)
 fig,axes=plt.subplots(2,3,figsize=(15,7))
 fig.subplots_adjust(left=.055,right=.99,bottom=.10,top=.90,wspace=.25,hspace=.55)
 for row,case in enumerate(('svd-large','pca-large')):
  name='SVD Large' if row==0 else 'PCA Large'
  for col,(field,title) in enumerate((('raw_seconds','Raw executor time (s)'),
                ('minmax','Independent min-max'),('cusum','CUSUM + quadratic fit'))):
   detail=case=='pca-large' and not full and col<2
   ax=axes[row,col]
   for lang,color in colors.items():
    allrows=[r for r in trans if r['case']==case and r['implementation']==lang]
    # Transformation values always come from the full application, not the window.
    v=np.array([float(r['raw_seconds']) for r in allrows])
    u=(v-v.min())/np.ptp(v)
    c=np.cumsum((v-v.mean())/v.std(ddof=0))
    assert np.allclose(u,[float(r['minmax']) for r in allrows])
    assert np.allclose(c,[float(r['cusum']) for r in allrows])
    rows=[r for r in allrows if not detail or int(r['position']) in windows[lang]]
    x=[int(r['position']) for r in rows]; y=[float(r[field]) for r in rows]
    ax.plot(x,y,color=color,lw=1.25,label='Scala' if lang=='scala' else 'PySpark')
    if col==2:
     ax.plot(x,[float(r['quadratic_fit']) for r in rows],color=color,ls='--',lw=1.3)
    if not full:
     records.extend(dict(figure=5,case=case,implementation=lang,metric=field,
      position=i,value=v,view='detail' if detail else 'complete') for i,v in zip(x,y))
   heading=name+(' — detail 526–565' if detail else ' — all tasks')
   setup(ax,heading+'\n'+title)
   if col<2:ax.set_ylim(bottom=0)
   if col==0:ax.legend(loc='best',fontsize=10)
   if col==2:
    ax.legend(handles=[Line2D([],[],color='.25',lw=1.25,label='CUSUM'),
      Line2D([],[],color='.25',ls='--',lw=1.3,label='Quadratic fit')],fontsize=10,loc='best')
 save(fig,'figure5-transforms'+suffix)
with (OUT/'plotted-observations.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
(OUT/'validation.json').write_text(json.dumps({'pair':1,'pca_detail_positions':[526,565],
 'selection_rule':'First 40 consecutive task positions of final 500-task stage (stage 7), same in both applications',
 'scope':'Post hoc illustration window; not a representative sample or independent replication',
 'svd_tasks_per_implementation':102,'pca_full_tasks_per_implementation':1047,
 'normalization_and_cusum':'Computed on full application; never recomputed on illustration window',
 'line_artists_only':True,'no_smoothing_or_interpolation':True,'all_source_data_preserved':True,
 'source_sha256':{name:hashlib.sha256((SRC/name).read_bytes()).hexdigest() for name in
 ('task-metrics-raw.csv','figure5-transformed-values.csv')}},indent=2))
print(OUT)
