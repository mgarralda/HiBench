# Current v2.5.0 evidence for the SSRN manuscript

All results below come from the final campaign. No data from a different input preset are pooled into these summaries.

## Protocol

Four cases, one infrastructure/cache warmup per implementation, then three measured pairs per case. Pair orders are Scala/PySpark, PySpark/Scala, Scala/PySpark. Every execution is a fresh Spark application. Warmup does not imply a persistent warmed JVM or Python process. With three pairs the starting order is alternating but not perfectly balanced.

SVD Large: 500,000 x 1,000, 100 retained singular values. PCA Large: 4,000,000 x 1,000, k=10. Repartition Small: in-memory, 14 generation partitions x 3,200,000 records x 200 bytes; cached, output disabled. Sleep Small: 3 seconds per sleep task, 14 generation partitions. Effective settings in each run are authoritative.

SVD/PCA use two executors x two cores, 2 GiB executor/driver heaps. Repartition/Sleep use two executors x one core, 2 GiB executor/driver heaps. Driver container quota is four CPUs. Native thread limits are 4/1 for Large and 1/1 for Small (driver/executor). Configured limits do not establish active thread counts.

## Tables

### resources

Recorded execution conditions. Executor counts/cores and heaps are Spark settings; driver CPU is a container quota; native thread values are configured driver/executor limits, not active-thread measurements.

| Case | Executors x cores | Heap executor/driver | Driver quota | Native limits |
|---|---|---|---|---|
| SVD Large | 2 x 2 | 2g / 2g | 4 CPUs | 4 / 1 |
| PCA Large | 2 x 2 | 2g / 2g | 4 CPUs | 4 / 1 |
| Repartition Small | 2 x 1 | 2g / 2g | 4 CPUs | 1 / 1 |
| Sleep Small | 2 x 1 | 2g / 2g | 4 CPUs | 1 / 1 |

### timings

Application and workload timing across three measured runs per implementation. Values are median [minimum, maximum], in seconds. Warmups are excluded.

| Case | Implementation | Submission (s) | Application (s) | Job union (s) |
|---|---|---|---|---|
| SVD Large | scala | 50.316 [50.308, 55.333] | 46.044 [43.638, 50.594] | 31.482 [28.823, 33.018] |
| SVD Large | pyspark | 400.902 [390.970, 405.931] | 393.551 [386.285, 398.622] | 379.757 [372.812, 384.628] |
| PCA Large | scala | 190.547 [190.467, 220.558] | 186.879 [184.478, 217.199] | 173.430 [171.289, 204.715] |
| PCA Large | pyspark | 190.531 [190.521, 225.586] | 187.246 [185.460, 219.993] | 173.466 [172.853, 207.179] |
| Repartition Small | scala | 65.347 [55.350, 65.367] | 59.027 [51.365, 59.464] | 44.488 [39.663, 46.513] |
| Repartition Small | pyspark | 40.354 [40.321, 40.364] | 34.735 [34.691, 35.157] | 22.916 [22.876, 23.243] |
| Sleep Small | scala | 40.282 [40.278, 40.289] | 34.024 [33.977, 34.457] | 22.270 [22.198, 22.282] |
| Sleep Small | pyspark | 40.357 [40.319, 40.361] | 35.786 [35.314, 35.792] | 23.146 [22.944, 23.182] |

### structure

Execution counts across three measured applications per implementation; ranges are shown if counts vary. Stages are executed stage attempts; tasks are successful attempts.

| Case | Implementation | Jobs | Stages | Tasks | Failed tasks |
|---|---|---|---|---|---|
| SVD Large | scala | 3 | 3 | 102 | 0 |
| SVD Large | pyspark | 3 | 3 | 102 | 0 |
| PCA Large | scala | 7 | 9 | 1047 | 0 |
| PCA Large | pyspark | 7 | 9 | 1047 | 0 |
| Repartition Small | scala | 5 | 5 | 243 | 0 |
| Repartition Small | pyspark | 5 | 5 | 243 | 0 |
| Sleep Small | scala | 2 | 2 | 15 | 0 |
| Sleep Small | pyspark | 2 | 2 | 15 | 0 |

### svd-task-summary

Task-counter sums and per-task medians for the first measured SVD Large pair. Sum changes are 100(PySpark/Scala-1). Task-counter sums are not wall-clock durations.

| Metric | Scala (sum; median) | PySpark (sum; median) | Sum change |
|---|---|---|---|
| Observed tasks | 102 | 102 | -- |
| Input (MiB) | 3,817.349; 38.173 | 3,817.349; 38.173 | +0.00% |
| Task duration (s) | 81.084; 0.635 | 1,462.273; 14.433 | +1703.41% |
| Executor runtime (s) | 77.332; 0.615 | 1,452.558; 14.414 | +1778.34% |
| JVM-thread CPU (s) | 66.865; 0.584 | 4.245; 0.027 | -93.65% |
| Deserialization (s) | 2.334; 0.003 | 7.912; 0.004 | +238.99% |
| Shuffle write (MiB) | 382.109; 3.821 | 382.132; 3.821 | +0.01% |

### repartition-stages

Summed task-level ExecutorRunTime for executed stages in the first measured Repartition Small pair. Values are not stage wall times; roles are inferred from plans and stage context.

| Stage ID | Observed role | Tasks | Scala (s) | PySpark (s) |
|---|---|---|---|---|
| 0 | Generation and cache population | 14 | 23.494 | 15.378 |
| 1 | Cache count | 14 | 16.869 | 2.840 |
| 3 | Small aggregate | 1 | 0.174 | 0.107 |
| 4 | Cache read and shuffle write | 14 | 26.242 | 19.081 |
| 6 | Final shuffle | 200 | 4.141 | 4.186 |
| Total | All executed stages | 243 | 70.920 | 41.592 |

### case-synthesis

Evidence and interpretation from the final cases. Three measured applications per implementation; no causal language effects are inferred.

| Case | Recorded evidence | Interpretation supported |
|---|---|---|
| SVD Large | Same 3 jobs, 3 stages and 102 tasks in all measured applications; nearly equal shuffle-write bytes. | Matching aggregate structure coexists with distinct implementation paths and task-runtime profiles. |
| PCA Large | Shared Spark ML estimator; 7 jobs, 9 stages and 1,047 tasks in all measured applications. | Shared computational core with close observed median submission times; no statistical equivalence claim. |
| Repartition Small | Distinct JVM generation routes; 5 jobs, 5 stages and 243 tasks in both implementations. | Differences localize mainly to generation/cache stages; the final shuffle-stage task sums are close in the displayed pair. |
| Sleep Small | Explicit Python UDF boundary; 14 three-second sleep tasks plus the final aggregate task. | The boundary is visible in plans while application-duration medians are close under this synthetic condition. |
