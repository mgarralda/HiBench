# SVD phase timers

| Implementation | Timer | Median (s) | Range (s) |
|---|---|---|---|
| scala | gram_action_s | 32.155 | [28.936, 34.164] |
| scala | matrix_construction_s | 0.071 | [0.059, 0.104] |
| scala | eigendecomposition_s | 1.612 | [1.539, 1.769] |
| scala | application_lifecycle_s | 46.173 | [43.754, 50.694] |
| scala | workload_s | 35.571 | [33.024, 38.098] |
| pyspark | gram_action_s | 381.101 | [373.797, 385.832] |
| pyspark | matrix_construction_s | 0.012 | [0.011, 0.028] |
| pyspark | eigendecomposition_s | 0.100 | [0.082, 0.149] |
| pyspark | application_lifecycle_s | 394.196 | [386.974, 399.028] |
| pyspark | workload_s | 383.546 | [375.974, 388.375] |

Timers may nest; do not add these rows or combine them additively with task counters.
