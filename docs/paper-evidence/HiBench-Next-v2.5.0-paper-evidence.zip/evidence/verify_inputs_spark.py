import json
from pyspark.sql import SparkSession,functions as F
from pyspark.ml.functions import vector_to_array
spark=SparkSession.builder.appName('SSRN independent dataset verification').getOrCreate()
results=[]
for item in [{"workload": "ml.svd", "path": "hdfs://spark-cluster-master:9000/HiBench-SSRN-v250-20261016/datasets/420273e12748bfaceb8b1486-38191563/SVD/normal-parquet-v1/Input/large", "scale": "large"}, {"workload": "ml.pca", "path": "hdfs://spark-cluster-master:9000/HiBench-SSRN-v250-20261016/datasets/f099fdc3718d9a3866afe03b-217f9fb0/PCA/gaussian-parquet-v1/Input/large", "scale": "large"}]:
 d=spark.read.parquet(item['path'])
 dims=F.size(vector_to_array('features'))
 row=d.agg(F.count('*').alias('rows'),F.countDistinct('id').alias('distinct_ids'),F.min('id').alias('min_id'),F.max('id').alias('max_id'),F.min(dims).alias('min_features'),F.max(dims).alias('max_features')).first().asDict()
 results.append(dict(**item,**row,schema=d.schema.jsonValue()))
print('SSRN_INPUT_CHECK='+json.dumps(results))
spark.stop()
