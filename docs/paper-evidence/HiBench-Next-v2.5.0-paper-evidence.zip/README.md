# HiBench Next v2.5.0 — paper evidence

This archive supports the four-case campaign reported in the HiBench Next paper.
It is separate from the software release DOI (10.5281/zenodo.23400663).

## Contents

- `evidence/`: 34 original Spark event logs (24 measured applications, eight
  warmups, two preparations), run results, console logs, effective overrides,
  provenance, input manifests/checksums, numerical-library and image identities,
  and independent validation records.
- `derived/`: application/stage/task CSVs, three-repetition timing summaries,
  physical plans, numerical checks and the tables used for the manuscript.
- `figures/`: final Figures 3–5, full-sequence supplements S1/S2, captions,
  displayed observations and view-selection metadata. PNG and SVG are supplied.
- `scripts/`: event-log analysis, final figure rendering and campaign/input-check
  scripts. Cluster access is needed only for rerunning the campaign/input checks.
- `reproduce.py`: regenerate tables and figures offline.
- `SHA256SUMS`: SHA-256 for every other file in this archive.

## Protocol and scope

SVD Large (500,000 × 1,000, 100 singular values), PCA Large (4,000,000 × 1,000,
10 components), in-memory Repartition Small (44.8 million 200-byte records), and
Sleep Small (14 three-second sleep tasks plus an aggregate task). One warmup
per implementation/case, then three measured Scala/PySpark pairs with starting
order Scala, PySpark, Scala. Each run is a fresh application. Spark 3.5.9,
Scala 2.12.18, Java 11 and Hadoop 3.3.6; YARN client on one shared-host Docker
laboratory. Effective per-run settings remain authoritative.

All 24 measured applications succeeded: 8,442 successful task attempts, no
failed attempts. Task observations are not independent run replications.
SVD and PCA reuse their respective materialized inputs. All three SVD pairs
pass checks for 100 singular values and all three PCA pairs pass checks for
10 explained-variance values (rtol=1e-6, atol=1e-8). These checks do not establish
full SVD reconstruction or materialized PCA-projection equivalence.

The first measured pair was selected before execution for the main profiles.
PCA detail positions 526–565 were selected afterwards for readability: the
first 40 tasks of its final 500-task stage. Raw/min-max PCA panels show this
labelled window; CUSUM and fits use the full application. Complete sequences
are supplied as supplements. No smoothing or area fills are used.

## Offline regeneration

Extract this archive and run from its directory:

```sh
python -m pip install numpy==1.26.4 matplotlib==3.9.4
python reproduce.py --output regenerated
```

Check `derived/analysis-environment.json` for the recorded analysis versions;
use those versions if they differ from your local environment. The helper uses
an isolated temporary workspace and preserves the archived files. Numerical
CSVs are the comparison reference; image bytes may depend on rendering/fonts.
The figure captions are editorial text, supplied rather than regenerated.

## Boundaries and exclusions

The large materialized datasets are not copied here; their generator conditions,
row/dimension checks, HDFS references and physical-file checksums are included.
File checksums do not establish canonical logical-content fingerprints.
The executed workload JAR is identified by SHA-256 and release source commit;
the binary is not duplicated in this archive. Rebuild from the identified
software release; a new build need not be byte-identical.
Working SQLite state, system-monitor HTML/samples, duplicate logs, manuscript
review notes, superseded figure styles and unrelated experimental campaigns
are excluded. System-monitor traces are not used by these task-profile figures.

Software source: v2.5.0, commit
`7b6843bd4925a7bc5972b7b4513d43d0c4035a1a`.
The controller revision is recorded separately in `evidence/campaign.json`.
The 144-workload/tier configuration audit and separate catalog functional checks
are not reproduced by this four-case archive; their scope is distinct.

No general language ranking, causal Python penalty, runtime scaling law or
downstream predictive-model benefit is established by this campaign.

Copyright 2026 Mariano Garralda-Barrio. Distributed under the repository's
Apache-2.0 license; source-file attribution and notices remain applicable.
