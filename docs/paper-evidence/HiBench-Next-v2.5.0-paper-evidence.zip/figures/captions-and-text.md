# Updated captions and text

## Figure 4

Raw task metrics for the first measured Scala/PySpark pair of SVD Large
(500,000 × 1,000; top) and PCA Large (4,000,000 × 1,000; bottom). Blue and
orange lines identify Scala and PySpark. Panels report executor runtime,
executing JVM-thread CPU time, deserialization time and shuffle-write bytes,
converted to seconds or MiB. SVD panels show all 102 task positions. PCA panels
show a zoomed view of 40 out of the 1,047 successful tasks per application
(positions 526–565): the first 40 consecutive tasks of the final 500-task stage,
using the same position window in both applications. This
post hoc illustration window is not a representative sample or an additional
replicate. No values within the window are omitted, smoothed or averaged.
Ordering is by ascending Task ID; positions are not elapsed time and do not
establish semantic task alignment. Independent y-scales are used. Complete
1,047-task PCA profiles are supplied in supplementary Figure S1; tables retain
full-application sums and medians.

## Figure 5

ExecutorRunTime representations for the same measured pairs as Figure 4.
Columns show raw seconds, independent min-max scaling, and cumulative
population-standardized deviations with a least-squares polynomial fit of degree
at most two. Blue denotes Scala and orange denotes PySpark; solid lines show
the observed series or CUSUM and dashed lines show polynomial fits. SVD panels
show all 102 tasks per application. The PCA raw and min-max panels show a
zoomed view of 40 out of the 1,047 successful tasks per application (positions
526–565), as in Figure 4; the PCA CUSUM and fit show the complete
1,047-task application. Normalization, standardization and fitting always use
the complete application; they are not recalculated on the displayed detail.
Task order is ascending Task ID, not elapsed time. Complete representations
are supplied in supplementary Figure S2.

## Supplementary Figure S1

Complete raw task profiles underlying Figure 4, with all 102 SVD and 1,047 PCA
task positions per implementation. Lines connect successive observations;
dense regions result from rapid task-to-task variation, not area fills.

## Supplementary Figure S2

Complete raw, min-max and CUSUM representations underlying Figure 5. All
observations are retained. Solid lines show observed/derived series and dashed
lines show the degree-at-most-two least-squares fits.

## Replace the current sentence about displayed PCA observations

Replace “For PCA, each implementation contributes 1,047 task positions to the
displayed raw profiles” with:

> Each PCA application contains 1,047 successful task observations. Figures 4
> and 5 use a labelled consecutive-task detail for the dense raw and min-max
> panels, while the supplementary figures retain the complete sequences. The
> detail reveals local variation without changing full-application summaries
> or recomputing the characterization transforms.

## Integration

Use `figure4-raw.png` and `figure5-transforms.png` at full text width with their
natural aspect ratio. SVG versions preserve vector geometry. Add
`figure4-raw-complete` and `figure5-transforms-complete` as supplementary Figures
S1 and S2, or give their actual supplement filenames in the captions. The
numeric results in the manuscript tables do not change. This is a change of
display scope for the explicitly labelled PCA panels, not a new experiment.

The first measured application pair was selected before execution; the PCA
detail window was introduced afterwards for readability. Do not describe the
window itself as selected before the campaign.
