"""Offline regeneration. Requires NumPy and Matplotlib; no cluster required."""
from pathlib import Path
import argparse,shutil,subprocess,sys,tempfile
p=argparse.ArgumentParser();p.add_argument('--output',default='regenerated');a=p.parse_args()
base=Path(__file__).resolve().parent;dest=Path(a.output).resolve()
with tempfile.TemporaryDirectory(prefix='hibench-paper-') as temp:
 root=Path(temp);(root/'pyproject.toml').write_text('');(root/'hibench').mkdir()
 source=root/'report/ssrn-v250-final-20261016'
 shutil.copytree(base/'evidence',source)
 scripts=source/'scripts';shutil.copytree(base/'scripts',scripts)
 subprocess.run([sys.executable,str(scripts/'analyze_campaign.py')],check=True)
 derived=source/'derived'
 shutil.copytree(derived,root/'output/ssrn-v250-final-20261016')
 visual=root/'report/paper-review-main27';visual.mkdir()
 shutil.copy2(scripts/'build_original_style.py',visual/'build_original_style.py')
 subprocess.run([sys.executable,str(visual/'build_original_style.py')],check=True)
 shutil.copytree(derived,dest/'derived',dirs_exist_ok=True)
 shutil.copytree(root/'output/paper-figures-final',dest/'figures',dirs_exist_ok=True)
print('Regenerated tables and figures:',dest)
